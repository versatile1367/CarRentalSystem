create view info1 as
select `a`.`INFOID`  AS `infoid`,
       `a`.`CARID`   AS `carid`,
       `a`.`CUSID`   AS `cusid`,
       `a`.`STUFFID` AS `stuffid`,
       `b`.`CNAME`   AS `cname`,
       `c`.`ENAME`   AS `ename`
from ((`cr_data`.`diary` `a` left join `cr_data`.`customerinfo` `b` on ((`a`.`CUSID` = `b`.`ID`)))
         left join `cr_data`.`employeeinfo` `c` on ((`a`.`STUFFID` = `c`.`ID`)));

